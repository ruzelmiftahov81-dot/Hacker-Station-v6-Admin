using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Security.Principal;
using System.Text;

public class AdminUltimateHub : Form {
    TextBox edit;
    string logDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "HACK_BASE");

    [STAThread] static void Main() {
        // Проверка на права админа при старте
        if (!IsAdmin()) {
            ProcessStartInfo psi = new ProcessStartInfo {
                FileName = Application.ExecutablePath,
                Verb = "runas", // Требуем права админа
                UseShellExecute = true
            };
            try { Process.Start(psi); } catch { }
            return;
        }
        Application.Run(new AdminUltimateHub());
    }

    static bool IsAdmin() {
        WindowsIdentity id = WindowsIdentity.GetCurrent();
        WindowsPrincipal principal = new WindowsPrincipal(id);
        return principal.IsInRole(WindowsBuiltInRole.Administrator);
    }

    public AdminUltimateHub() {
        if (!Directory.Exists(logDir)) Directory.CreateDirectory(logDir);
        this.BackColor = Color.Black; this.Size = new Size(1150, 850);
        this.StartPosition = FormStartPosition.CenterScreen; this.FormBorderStyle = FormBorderStyle.None;

        Panel top = new Panel { Dock = DockStyle.Top, Height = 45, BackColor = Color.FromArgb(30, 30, 30) };
        Button btnX = new Button { Text = "X", Dock = DockStyle.Right, Width = 50, FlatStyle = FlatStyle.Flat, ForeColor = Color.White };
        btnX.Click += (s, e) => Application.Exit();
        Button btnMax = new Button { Text = "□", Dock = DockStyle.Right, Width = 50, FlatStyle = FlatStyle.Flat, ForeColor = Color.White };
        btnMax.Click += (s, e) => this.WindowState = (this.WindowState == FormWindowState.Maximized) ? FormWindowState.Normal : FormWindowState.Maximized;
        Button btnMin = new Button { Text = "_", Dock = DockStyle.Right, Width = 50, FlatStyle = FlatStyle.Flat, ForeColor = Color.White };
        btnMin.Click += (s, e) => this.WindowState = FormWindowState.Minimized;
        top.Controls.Add(btnMin); top.Controls.Add(btnMax); top.Controls.Add(btnX);

        MenuStrip ms = new MenuStrip { BackColor = Color.FromArgb(20, 20, 20), ForeColor = Color.Lime };
        
        ToolStripMenuItem file = new ToolStripMenuItem("ФАЙЛ");
        string[] exts = { "EXE", "APK", "ZIP", "JAVA", "PY", "CPP", "CS", "GO", "SH", "BAT", "VBS", "JS", "BIN", "SQL", "PHP", "RB", "JSON", "XML", "HTML", "CSS" };
        foreach (string ex in exts) file.DropDownItems.Add("СКАЧАТЬ_." + ex, null, (s, e) => MessageBox.Show(ex + " PAYLOAD READY"));
        file.DropDownItems.Add("ОЧИСТИТЬ", null, (s, e) => edit.Clear());

        ToolStripMenuItem tools = new ToolStripMenuItem("ЗАПУСК (ROOT)");
        tools.DropDownItems.Add("CMD (ADMIN)", null, (s, e) => Process.Start("cmd.exe"));
        tools.DropDownItems.Add("POWERSHELL ISE (ADMIN)", null, (s, e) => Process.Start("powershell_ise.exe"));
        tools.DropDownItems.Add("ДИСПЕТЧЕР ЗАДАЧ", null, (s, e) => Process.Start("taskmgr.exe"));
        tools.DropDownItems.Add("РЕАКТОР РЕЕСТРА", null, (s, e) => Process.Start("regedit.exe"));

        ToolStripMenuItem hackInfo = new ToolStripMenuItem("ХАК-ИНФО");
        hackInfo.DropDownItems.Add("IP_CONFIG", null, (s, e) => ExecuteCmd("ipconfig /all"));
        hackInfo.DropDownItems.Add("WIFI_PASSWORDS", null, (s, e) => ExecuteCmd("netsh wlan show profiles"));
        hackInfo.DropDownItems.Add("NET_STAT", null, (s, e) => ExecuteCmd("netstat -an"));

        ms.Items.Add(file); ms.Items.Add(tools); ms.Items.Add(hackInfo);
        ms.Items.Add(new ToolStripMenuItem("БАЗА", null, (s, e) => Process.Start("explorer.exe", logDir)));

        edit = new TextBox { Multiline = true, Dock = DockStyle.Fill, BackColor = Color.Black, ForeColor = Color.Lime, BorderStyle = BorderStyle.None, Font = new Font("Consolas", 14), ScrollBars = ScrollBars.Vertical };
        edit.AppendText("> ROOT_SYSTEM v16.0 ONLINE. PRIVILEGED ACCESS ENABLED.\r\n> ");
        edit.KeyDown += (s, e) => {
            if (e.KeyCode == Keys.Enter) {
                string lastLine = edit.Lines[edit.Lines.Length - 1].Replace("> ", "").Trim();
                if (!string.IsNullOrEmpty(lastLine)) ExecuteCmd(lastLine);
            }
        };
        this.Controls.Add(edit); this.Controls.Add(ms); this.Controls.Add(top);
    }

    void ExecuteCmd(string c) {
        try {
            ProcessStartInfo p = new ProcessStartInfo("cmd.exe", "/c " + c) { CreateNoWindow = true, UseShellExecute = false, RedirectStandardOutput = true, StandardOutputEncoding = Encoding.GetEncoding(866) };
            edit.AppendText(Environment.NewLine + Process.Start(p).StandardOutput.ReadToEnd() + Environment.NewLine + "> ");
            edit.SelectionStart = edit.Text.Length; edit.ScrollToCaret();
        } catch { }
    }
}
